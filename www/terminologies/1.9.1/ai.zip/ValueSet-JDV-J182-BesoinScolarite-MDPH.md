# JDV_J182_BesoinScolarite_MDPH - Terminologies de Santé v1.9.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **JDV_J182_BesoinScolarite_MDPH**

## ValueSet: JDV_J182_BesoinScolarite_MDPH 

| | | |
| :--- | :--- | :--- |
| *Official URL*:https://mos.esante.gouv.fr/NOS/JDV_J182-BesoinScolarite-MDPH/FHIR/JDV-J182-BesoinScolarite-MDPH | *Version*:20210924120000 | |
| Active as of 2021-09-24 | *Responsible:*Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris | *Computable Name*:JDV_J182_BesoinScolarite_MDPH |
| *Other Identifiers:*OID:1.2.250.1.213.3.4.17 | | |

 
Caractérise les besoins d’aide de la personne en matière de scolarité, en lien avec les apprentissages 

 **References** 

Ce jeu de valeurs n'est pas utilisé ici ; il peut être utilisé autre part (par exemple dans les spécifications et / ou implémentations qui utilisent ce contenu)

###  Recherche en live sur le SMT 

Indiquer un mot clé puis taper sur "enter" :

```
Requête sur le SMT
```

### Définition logique (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "JDV-J182-BesoinScolarite-MDPH",
  "meta" : {
    "versionId" : "4",
    "lastUpdated" : "2025-07-02T17:05:34.417+00:00",
    "profile" : ["http://hl7.org/fhir/StructureDefinition/shareablevalueset"]
  },
  "language" : "fr-FR",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/resource-effectivePeriod",
    "valuePeriod" : {
      "start" : "2021-09-24T12:00:00+01:00"
    }
  }],
  "url" : "https://mos.esante.gouv.fr/NOS/JDV_J182-BesoinScolarite-MDPH/FHIR/JDV-J182-BesoinScolarite-MDPH",
  "identifier" : [{
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:1.2.250.1.213.3.4.17"
  }],
  "version" : "20210924120000",
  "name" : "JDV_J182_BesoinScolarite_MDPH",
  "status" : "active",
  "experimental" : false,
  "date" : "2021-09-24T12:00:00+01:00",
  "publisher" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
  "description" : "Caractérise les besoins d'aide de la personne en matière de scolarité, en lien avec les apprentissages",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FRA"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "https://mos.esante.gouv.fr/NOS/TRE_R323-BesoinScolarite/FHIR/TRE-R323-BesoinScolarite",
      "concept" : [{
        "code" : "01",
        "display" : "Pour lire"
      },
      {
        "code" : "02",
        "display" : "Pour écrire, prendre des notes"
      },
      {
        "code" : "03",
        "display" : "Pour calculer"
      },
      {
        "code" : "04",
        "display" : "Pour comprendre, suivre les consignes"
      },
      {
        "code" : "05",
        "display" : "Pour organiser, contrôler son travail"
      },
      {
        "code" : "06",
        "display" : "Pour l'utilisation du matériel"
      }]
    },
    {
      "system" : "https://mos.esante.gouv.fr/NOS/TRE_R302-ContexteCodeComplementaire/FHIR/TRE-R302-ContexteCodeComplementaire",
      "concept" : [{
        "code" : "02",
        "display" : "Autre"
      }]
    }]
  }
}

```
