# JDV_J206_PrestationNonObligatoireIncluse_ROR - Terminologies de Santé v1.8.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **JDV_J206_PrestationNonObligatoireIncluse_ROR**

## ValueSet: JDV_J206_PrestationNonObligatoireIncluse_ROR 

| | | |
| :--- | :--- | :--- |
| *Official URL*:https://mos.esante.gouv.fr/NOS/JDV_J206-PrestationNonObligatoireIncluse-ROR/FHIR/JDV-J206-PrestationNonObligatoireIncluse-ROR | *Version*:20220826120000 | |
| Active as of 2022-08-26 | *Responsible:*Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris | *Computable Name*:JDV_J206_PrestationNonObligatoireIncluse_ROR |
| *Other Identifiers:*OID:1.2.250.1.213.3.4.38 | | |

 
Prestations non obligatoire incluses 

 **References** 

Ce jeu de valeurs n'est pas utilisé ici ; il peut être utilisé autre part (par exemple dans les spécifications et / ou implémentations qui utilisent ce contenu)

###  Recherche en live sur le SMT 

Indiquer un mot clé puis taper sur "enter" :

```
Requête sur le SMT
```

### Définition logique (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "JDV-J206-PrestationNonObligatoireIncluse-ROR",
  "meta" : {
    "versionId" : "4",
    "lastUpdated" : "2025-07-02T17:05:46.873+00:00",
    "profile" : ["http://hl7.org/fhir/StructureDefinition/shareablevalueset"]
  },
  "language" : "fr-FR",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/resource-effectivePeriod",
    "valuePeriod" : {
      "start" : "2022-08-26T12:00:00+01:00"
    }
  }],
  "url" : "https://mos.esante.gouv.fr/NOS/JDV_J206-PrestationNonObligatoireIncluse-ROR/FHIR/JDV-J206-PrestationNonObligatoireIncluse-ROR",
  "identifier" : [{
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:1.2.250.1.213.3.4.38"
  }],
  "version" : "20220826120000",
  "name" : "JDV_J206_PrestationNonObligatoireIncluse_ROR",
  "status" : "active",
  "experimental" : false,
  "date" : "2022-08-26T12:00:00+01:00",
  "publisher" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
  "description" : "Prestations non obligatoire incluses",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FRA"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "https://mos.esante.gouv.fr/NOS/TRE_R264-PrestationNonObligatoireIncluse/FHIR/TRE-R264-PrestationNonObligatoireIncluse",
      "concept" : [{
        "code" : "01",
        "display" : "Entretien du linge du résident non délicat"
      },
      {
        "code" : "02",
        "display" : "Marquage du linge"
      },
      {
        "code" : "03",
        "display" : "Fourniture de produits d'hygiène corporelle (savon, gel douche, shampoing, dentifrice...)"
      },
      {
        "code" : "04",
        "display" : "Mise à disposition d'un poste de téléphonie dans la chambre"
      },
      {
        "code" : "05",
        "display" : "Appels téléphoniques entrants non facturés en sus"
      },
      {
        "code" : "06",
        "display" : "Appels téléphoniques sortants non facturés en sus"
      },
      {
        "code" : "07",
        "display" : "Mise à disposition d'un poste de télévision dans la chambre"
      },
      {
        "code" : "08",
        "display" : "Internet dans la chambre (abonnement/accès au réseau Wifi)"
      },
      {
        "code" : "09",
        "display" : "Prestation de coiffure (shampoing, coupe)"
      },
      {
        "code" : "10",
        "display" : "Prestation esthétique de base"
      },
      {
        "code" : "11",
        "display" : "Prestation de pédicurie-podologie (hors prescription médicale)"
      }]
    }]
  }
}

```
