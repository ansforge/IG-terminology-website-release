# Jeux de valeurs pour la Note de Vaccination - Terminologies de Santé v1.14.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Jeux de valeurs pour la Note de Vaccination**

## CodeSystem: Jeux de valeurs pour la Note de Vaccination 

| | | |
| :--- | :--- | :--- |
| *Official URL*:https://smt.esante.gouv.fr/terminologie-catalogue-vaccins | *Version*:2026-04 | |
| Active as of 2026-04-01 | *Responsible:*Agence du Numérique en Santé (ANS) - 2-10 Rue d Oradour-sur-Glane, 75015 Paris | *Computable Name*:Catalogue_Vaccins |
| *Other Identifiers:*https://smt.esante.gouv.fr/#terminologie-catalogue-vaccins (use: secondary, ) | | |
| **Copyright/Legal**: [LOv2](https://github.com/etalab/licence-ouverte/blob/master/LO.md) | | |

 
Le Catalogue Vaccins permet de codifier les vaccins administrés à un patient pour produire une note de vaccination à des fins de partage dans le DMP/MES. Il permet de faire le lien entre une spécialité pharmaceutique vaccinale et une maladie. Il est construit à partir des standards sémantiques nationaux et internationaux interopérables dont les sources sont issues du RUIM-Référentiel Unique d’Interopérabilité du Médicament(ANSM), de l’ATC-Anatomique Thérapeutique Chimique(OMS (WHOCC)) et de NUVA-Nomenclature Unifiée des Vaccins(SYADEM). Il est destiné en particulier aux utilisateurs du secteur médico-social ou paramédical lorsqu’ils ne disposent pas d’un accès à une base de médicaments et d’un lecteur de datamatrix 

 Cette terminologie de référence (CodeSystem) est référencé dans la définition de contenu des jeux de valeurs (ValueSet) suivants : 

* Cette terminologie de référence (CodeSystem) n'est pas utilisée ici; elle peut être utilisée ailleurs (par exemple spécifications et/ou implémentations qui utilisent ce contenu)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "terminologie-catalogue-vaccins",
  "meta" : {
    "versionId" : "1",
    "lastUpdated" : "2026-06-04T16:37:44.909+02:00",
    "profile" : ["http://hl7.org/fhir/StructureDefinition/shareablecodesystem"]
  },
  "language" : "fr-FR",
  "url" : "https://smt.esante.gouv.fr/terminologie-catalogue-vaccins",
  "identifier" : [{
    "use" : "secondary",
    "system" : "https://smt.esante.gouv.fr/",
    "value" : "terminologie-catalogue-vaccins"
  }],
  "version" : "2026-04",
  "name" : "Catalogue_Vaccins",
  "title" : "Jeux de valeurs pour la Note de Vaccination",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-04-01T00:00:00Z",
  "publisher" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d Oradour-sur-Glane, 75015 Paris",
  "description" : "Le Catalogue Vaccins permet de codifier les vaccins administrés à un patient pour produire une note de vaccination à des fins de partage dans le DMP/MES. Il permet de faire le lien entre une spécialité pharmaceutique vaccinale et une maladie. Il est construit à partir des standards sémantiques nationaux et internationaux interopérables dont les sources sont issues du RUIM-Référentiel Unique d'Interopérabilité du Médicament(ANSM), de l'ATC-Anatomique Thérapeutique Chimique(OMS (WHOCC)) et de NUVA-Nomenclature Unifiée des Vaccins(SYADEM). Il est destiné en particulier aux utilisateurs du secteur médico-social ou paramédical lorsqu’ils ne disposent pas d’un accès à une base de médicaments et d’un lecteur de datamatrix",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FRA"
    }]
  }],
  "copyright" : "[LOv2](https://github.com/etalab/licence-ouverte/blob/master/LO.md)",
  "caseSensitive" : true,
  "valueSet" : "https://smt.esante.gouv.fr/terminologie-catalogue-vaccins?vs",
  "content" : "complete",
  "count" : 122,
  "property" : [{
    "code" : "CIP7",
    "uri" : "http://data.esante.gouv.fr/ansm/medicament/CIP7",
    "description" : "Code CIP7",
    "type" : "code"
  },
  {
    "code" : "ucdCode13",
    "uri" : "http://data.esante.gouv.fr/ansm/medicament/ucdCode13",
    "description" : "Code UCD13",
    "type" : "code"
  },
  {
    "code" : "ucdCode7",
    "uri" : "http://data.esante.gouv.fr/ansm/medicament/ucdCode7",
    "description" : "Code UCD7",
    "type" : "code"
  },
  {
    "code" : "libelleUCD",
    "uri" : "http://data.esante.gouv.fr/ansm/medicament/libelleUCD",
    "description" : "libelle UCD",
    "type" : "string"
  },
  {
    "code" : "codeCIS",
    "uri" : "http://data.esante.gouv.fr/ansm/medicament/codeCIS",
    "description" : "Code CIS",
    "type" : "code"
  },
  {
    "code" : "libelleCIS",
    "uri" : "http://data.esante.gouv.fr/ansm/medicament/libelleCIS",
    "description" : "Libelle CIS",
    "type" : "string"
  },
  {
    "code" : "codeATC",
    "uri" : "http://data.esante.gouv.fr/ansm/medicament/codeATC",
    "description" : "Code ATC",
    "type" : "code"
  },
  {
    "code" : "libelleATC",
    "uri" : "http://data.esante.gouv.fr/ansm/medicament/libelleATC",
    "description" : "Libelle ATC",
    "type" : "string"
  },
  {
    "code" : "classCIS",
    "uri" : "http://data.esante.gouv.fr/ansm/medicament/classCIS",
    "description" : "class CIS",
    "type" : "string"
  }],
  "concept" : [{
    "code" : "3400936466135",
    "display" : "VACCIN BCG AJVaccines, poudre et solvant pour suspension injectable. Vaccin BCG, lyophilisé - 5 flacon(s) de poudre en verre jaune(brun) - 5 flacon(s) de solvant en verre de 1 ml",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3646613"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400892615936"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9261593"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "AJV VAC BCG INJ FL+FL"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "61077869"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "VACCIN BCG AJVaccines, poudre et solvant pour suspension injectable. Vaccin BCG, lyophilisé"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07AN01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "tuberculose, bactérie vivante atténuée"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_61077869"
    }]
  },
  {
    "code" : "3400930244210",
    "display" : "MENQUADFI, solution injectable. Vaccin méningococcique conjugué des groupes A,C,W et Y - 1 flacon en verre unidose(s) de 0,5 mL avec seringue + 2 aiguilles",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890024341"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9002434"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "MENQUADFI INJ FL0,5ML +NEC"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "63064137"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "MENQUADFI, solution injectable. Vaccin méningococcique conjugué des groupes A,C,W et Y"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07AH08"
    },
    {
      "code" : "libelleATC",
      "valueString" : "méningocoques A,C,Y, W-135, antigènes polysaccharidiques tétravalents purifiés conjugués"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_63064137"
    }]
  },
  {
    "code" : "3400921702903",
    "display" : "MENVEO, poudre et solution pour solution injectable. Vaccin méningococcique des groupes A, C, W-135 et Y conjugué - 1 flacon(s) en verre - 1 flacon(s) en verre",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "2170290"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400893806425"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9380642"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "MENVEO INJ FL+FL"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "68046787"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "MENVEO, poudre et solution pour solution injectable. Vaccin méningococcique des groupes A, C, W-135 et Y conjugué"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07AH08"
    },
    {
      "code" : "libelleATC",
      "valueString" : "méningocoques A,C,Y, W-135, antigènes polysaccharidiques tétravalents purifiés conjugués"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_68046787"
    }]
  },
  {
    "code" : "3400922253930",
    "display" : "NIMENRIX, poudre et solvant pour solution injectable. Vaccin méningococcique conjugué des groupes A, C, W135 et Y - 1 flacon(s) en verre - 1 seringue(s) préremplie(s) en verre avec 2 aiguille(s)",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "2225393"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400893873601"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9387360"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "NIMENRIX INJ FL+SRG A/2AIG"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "69241562"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "NIMENRIX, poudre et solvant pour solution injectable. Vaccin méningococcique conjugué des groupes A, C, W135 et Y"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07AH08"
    },
    {
      "code" : "libelleATC",
      "valueString" : "méningocoques A,C,Y, W-135, antigènes polysaccharidiques tétravalents purifiés conjugués"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_69241562"
    }]
  },
  {
    "code" : "3400930096376",
    "display" : "TRUMENBA, suspension injectable en seringue préremplie. Vaccin méningococcique groupe B (recombinant, adsorbé) - 1 seringue préremplie en verre de 0,5 ml avec aiguille",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890015936"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9001593"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "TRUMENBA INJ SRG0,5ML"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "65802140"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "TRUMENBA, suspension injectable en seringue préremplie. Vaccin méningococcique groupe B (recombinant, adsorbé)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07AH09"
    },
    {
      "code" : "libelleATC",
      "valueString" : "méningocoque B, vaccin multicomposant"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_65802140"
    }]
  },
  {
    "code" : "3400926863036",
    "display" : "BEXSERO suspension injectable en seringue préremplie. Vaccin méningococcique groupe B (ADNr, composant, adsorbé) - 1 seringue(s) préremplie(s) en verre de 0,5 ml avec aiguille(s)",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "2686303"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400893978320"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9397832"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "BEXSERO INJ SRG0,5ML +AIG"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "64493883"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "BEXSERO suspension injectable en seringue préremplie. Vaccin méningococcique groupe B (ADNr, composant, adsorbé)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07AH09"
    },
    {
      "code" : "libelleATC",
      "valueString" : "méningocoque B, vaccin multicomposant"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_64493883"
    }]
  },
  {
    "code" : "3400930017609",
    "display" : "MENJUGATE 10 microgrammes, suspension injectable en seringue préremplie. Vaccin conjugué méningococcique groupe C - 1 seringue(s) préremplie(s) en verre de 0,6 ml",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400894100249"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9410024"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "MENJUGATE 10µG INJ SRG0,6ML"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "63301248"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "MENJUGATE 10 microgrammes, suspension injectable en seringue préremplie. Vaccin conjugué méningococcique groupe C"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07AH07"
    },
    {
      "code" : "libelleATC",
      "valueString" : "méningocoque C, antigène polysaccharidique purifié conjugué"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_63301248"
    }]
  },
  {
    "code" : "3400936277397",
    "display" : "NEISVAC, suspension injectable en seringue préremplie. Vaccin méningococcique polyosidique du groupe C (conjugué, adsorbé) - 1 seringue(s) préremplie(s) en verre de 0,5 ml avec 2 aiguille(s)",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3627739"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400892571089"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9257108"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "NEISVAC INJ SRG0,5ML +NEC"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "69261547"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "NEISVAC, suspension injectable en seringue préremplie. Vaccin méningococcique polyosidique du groupe C (conjugué, adsorbé)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07AH07"
    },
    {
      "code" : "libelleATC",
      "valueString" : "méningocoque C, antigène polysaccharidique purifié conjugué"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_69261547"
    }]
  },
  {
    "code" : "3400931837220",
    "display" : "VACCIN MENINGOCOCCIQUE A+C POLYOSIDIQUE, poudre et solvant pour suspension injectable en seringue préremplie - 1 flacon(s) en verre de 1  dose(s) - 1 seringue(s) préremplie(s) en verre de 0,5  ml",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3183722"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400890582605"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9058260"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "MERIEUX VAC MEN. A+C FL+SER."
    },
    {
      "code" : "codeCIS",
      "valueCode" : "61920725"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "VACCIN MENINGOCOCCIQUE A+C POLYOSIDIQUE, poudre et solvant pour suspension injectable en seringue préremplie"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07AH03"
    },
    {
      "code" : "libelleATC",
      "valueString" : "méningocoques A,C, antigènes polysaccharidiques bivalents purifiés"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_61920725"
    }]
  },
  {
    "code" : "3400930244371",
    "display" : "VAXNEUVANCE, suspension injectable en seringue préremplie.Vaccin pneumococcique polyosidique conjugué (15-valent, adsorbé) - 1 seringue préremplie en verre de 0,5 ml  + 1 aiguille séparée",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890033404"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9003340"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "VAXNEUVANCE INJ SRG0,5ML +1AIG"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "64355843"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "VAXNEUVANCE, suspension injectable en seringue préremplie.Vaccin pneumococcique polyosidique conjugué (15-valent, adsorbé)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07AL02"
    },
    {
      "code" : "libelleATC",
      "valueString" : "Pneumococcus, antigènes polysaccharidiques purifiés conjugués"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_64355843"
    }]
  },
  {
    "code" : "3400930247853",
    "display" : "PREVENAR 20, suspension injectable en seringue préremplie. Vaccin pneumococcique polyosidique conjugué (20-valent, adsorbé) - 1 seringue préremplie en verre de 0,5 ml + 1 aiguille",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890038331"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9003833"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "PREVENAR 20 INJ SRG0,5ML+AIG"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "62189757"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "PREVENAR 20, suspension injectable en seringue préremplie. Vaccin pneumococcique polyosidique conjugué (20-valent, adsorbé)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07AL02"
    },
    {
      "code" : "libelleATC",
      "valueString" : "Pneumococcus, antigènes polysaccharidiques purifiés conjugués"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_62189757"
    }]
  },
  {
    "code" : "3400930311462",
    "display" : "CAPVAXIVE, solution injectable en seringue préremplie. Vaccin pneumococcique polyosidique conjugué (21-valent) - 1 seringue préremplie unidose en verre de 0,5 mL + 1 aiguille",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890046732"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9004673"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "CAPVAXIVE INJ SRG0,5ML+1A"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "69077052"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "CAPVAXIVE, solution injectable en seringue préremplie. Vaccin pneumococcique polyosidique conjugué (21-valent)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07AL02"
    },
    {
      "code" : "libelleATC",
      "valueString" : "Pneumococcus, antigènes polysaccharidiques purifiés conjugués"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_69077052"
    }]
  },
  {
    "code" : "3400939901152",
    "display" : "PREVENAR 13 suspension injectable. Vaccin pneumococcique polyosidique conjugué (13-valent, adsorbé) - 1 seringue(s) préremplie(s) en verre de 0,5 ml avec aiguille(s)",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3990115"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400893428191"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9342819"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "PREVENAR 13 INJ SRG0,5ML A/A"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "67786749"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "PREVENAR 13 suspension injectable. Vaccin pneumococcique polyosidique conjugué (13-valent, adsorbé)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07AL02"
    },
    {
      "code" : "libelleATC",
      "valueString" : "Pneumococcus, antigènes polysaccharidiques purifiés conjugués"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_67786749"
    }]
  },
  {
    "code" : "3400935528001",
    "display" : "PNEUMOVAX solution injectable en flacon. Vaccin pneumococcique polyosidique - 1 flacon(s) en verre de 0,5 ml",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3552800"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400893141540"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9314154"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "PNEUMOVAX INJ FL0,5ML"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "66229252"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "PNEUMOVAX solution injectable en flacon. Vaccin pneumococcique polyosidique"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07AL01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "Pneumococcus, antigènes polysaccharidiques purifiés"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_66229252"
    }]
  },
  {
    "code" : "3400930044384",
    "display" : "PNEUMOVAX, solution injectable en seringue préremplie. Vaccin pneumococcique polyosidique - 1 seringue(s) préremplie(s) en verre de 0,5 ml avec 2 aiguille(s)",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400894259077"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9425907"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "PNEUMOVAX INJ SRG0,5ML A/2A"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "60614280"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "PNEUMOVAX, solution injectable en seringue préremplie. Vaccin pneumococcique polyosidique"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07AL01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "Pneumococcus, antigènes polysaccharidiques purifiés"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_60614280"
    }]
  },
  {
    "code" : "3400932857241",
    "display" : "VACCIN TETANIQUE PASTEUR, suspension injectable en seringue préremplie. Vaccin tétanique adsorbé - 1 seringue(s) préremplie(s) en verre de 0,5 ml",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3285724"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400891098624"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9109862"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "PASTEUR VAC TETAN. SV0,5ML"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "68747507"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "VACCIN TETANIQUE PASTEUR, suspension injectable en seringue préremplie. Vaccin tétanique adsorbé"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07AM01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "anatoxine tétanique"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_68747507"
    }]
  },
  {
    "code" : "3400933472016",
    "display" : "ACT-HIB 10 microgrammes/0,5 mL, poudre et solvant pour solution injectable en seringue préremplie. Vaccin conjugué de l'Haemophilus type b - 1 flacon(s) en verre - 1 seringue(s) préremplie(s) en verre de 0,5 mL",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3347201"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400891525915"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9152591"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "ACT-HIB INJ FL+SRG"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "61104024"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "ACT-HIB 10 microgrammes/0,5 mL, poudre et solvant pour solution injectable en seringue préremplie. Vaccin conjugué de l'Haemophilus type b"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07AG01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "Haemophilus influenzae B, antigène conjugué purifié"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_61104024"
    }]
  },
  {
    "code" : "3400936512580",
    "display" : "DUKORAL, suspension et poudre effervescente pour suspension buvable.Vaccin du choléra (inactivé, buvable) - 2 flacon(s) en verre de 3 ml - 2 sachet(s)-dose(s) polyester polyéthylène basse densité (PEBD) aluminium de 5,6 g",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3651258"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400892670294"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9267029"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "DUKORAL BUV FL+SACH"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "66974680"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "DUKORAL, suspension et poudre effervescente pour suspension buvable.Vaccin du choléra (inactivé, buvable)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07AE01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "vibrion cholérique inactivé entier"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_66974680"
    }]
  },
  {
    "code" : "3400930264966",
    "display" : "VAXCHORA, poudre effervescente et poudre pour suspension buvable. Vaccin anticholérique (vivant,recombiné,orale) - 1 sachet(s) papier polyéthylène basse densité (PEBD) aluminium - 1 sachet(s) papier aluminium polyéthylène basse densité (PEBD)",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890039000"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9003900"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "VAXCHORA BUV PDR SACH+SACH"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "69975093"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "VAXCHORA, poudre effervescente et poudre pour suspension buvable. Vaccin anticholérique (vivant,recombiné,orale)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07AE02"
    },
    {
      "code" : "libelleATC",
      "valueString" : "vibrion cholérique vivant atténué"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_69975093"
    }]
  },
  {
    "code" : "3400935147165",
    "display" : "SPIROLEPT 200 millions U/ml, suspension injectable en seringue préremplie. Vaccin leptospires inactivé - 1 seringue(s) préremplie(s) en verre de 1 ml avec aiguille",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3514716"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400892140629"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9214062"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "SPIROLEPT INJ SRG1ML"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "64175998"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "SPIROLEPT 200 millions U/ml, suspension injectable en seringue préremplie. Vaccin leptospires inactivé"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07AX01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "vaccins de la leptospirose"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_64175998"
    }]
  },
  {
    "code" : "3400930166123",
    "display" : "VIVOTIF, gélule gastro-résistante - plaquette(s) PVC polyéthylène PVDC aluminium de 3 gélule(s)",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890034159"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9003415"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "VIVOTIF GELU"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "68510344"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "VIVOTIF, gélule gastro-résistante"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07AP01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "typhoïde, bactérie vivante atténuée orale"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_68510344"
    }]
  },
  {
    "code" : "3400936993020",
    "display" : "TYPHIM Vi, solution injectable en seringue préremplie. Vaccin typhoïdique polyosidique - 1 seringue(s) préremplie(s) en verre de 0,5 ml avec deux aiguilles séparées",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3699302"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400893052150"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9305215"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "TYPHIM VI INJ SRG0,5ML 1 A/2AI"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "68790394"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "TYPHIM Vi, solution injectable en seringue préremplie. Vaccin typhoïdique polyosidique"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07AP03"
    },
    {
      "code" : "libelleATC",
      "valueString" : "typhoïde, antigène polysaccharidique purifié"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_68790394"
    }]
  },
  {
    "code" : "3400936992948",
    "display" : "TYPHIM Vi, solution injectable en seringue préremplie. Vaccin typhoïdique polyosidique - 1 seringue(s) préremplie(s) en verre de 0,5 ml avec 1 aiguille séparée",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3699294"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400890034296"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9003429"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "TYPHIM VI INJ SRG0,5ML 1 A/1AI"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "68790394"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "TYPHIM Vi, solution injectable en seringue préremplie. Vaccin typhoïdique polyosidique"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07AP03"
    },
    {
      "code" : "libelleATC",
      "valueString" : "typhoïde, antigène polysaccharidique purifié"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_68790394"
    }]
  },
  {
    "code" : "3400930198599",
    "display" : "DENGVAXIA, poudre et solvant pour suspension injectable en seringue préremplie. Vaccin dengue quadrivalent (vivant, atténué) - 1 flacon(s) en verre de 1 dose(s) - 1 seringue(s) préremplie(s) en verre de 0,5 ml + 2 aiguilles",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890019163"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9001916"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "DENGVAXIA SUSP INJ FL+SRG +A"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "69536790"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "DENGVAXIA, poudre et solvant pour suspension injectable en seringue préremplie. Vaccin dengue quadrivalent (vivant, atténué)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BX04"
    },
    {
      "code" : "libelleATC",
      "valueString" : "vaccins du virus de la dengue"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_69536790"
    }]
  },
  {
    "code" : "3400930266458",
    "display" : "QDENGA, poudre et solvant pour solution injectable en seringue préremplie - 1 flacon en verre de 1 dose - 1 seringue préremplie en verre de 0,5 mL + 2 aiguilles",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890029148"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9002914"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "QDENGA INJ FL+SRG +2AIG"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "69091949"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "QDENGA, poudre et solvant pour solution injectable en seringue préremplie"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BX04"
    },
    {
      "code" : "libelleATC",
      "valueString" : "vaccins du virus de la dengue"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_69091949"
    }]
  },
  {
    "code" : "3400930274170",
    "display" : "AREXVY, poudre et suspension pour suspension injectable. Vaccin du Virus Respiratoire Syncytial (VRS) (recombinant, avec adjuvant) - 1 flacon en verre de 120 microgrammes de poudre - 1 flacon en verre de 0,5 ml de suspension",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890034593"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9003459"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "AREXVY INJ FL+FL"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "64431629"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "AREXVY, poudre et suspension pour suspension injectable. Vaccin du Virus Respiratoire Syncytial (VRS) (recombinant, avec adjuvant)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BX05"
    },
    {
      "code" : "libelleATC",
      "valueString" : "vaccins du virus respiratoire syncytial"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_64431629"
    }]
  },
  {
    "code" : "3400930275573",
    "display" : "ABRYSVO, poudre et solvant pour solution injectable. Vaccin du virus respiratoire syncytial (bivalent, recombinant) - 1 flacon en verre + 1 seringue préremplie en verre de 0,5 mL + adaptateur pour flacon + aiguille(s)",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890042222"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9004222"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "ABRYSVO INJ FL+SRG0,5ML"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "60990140"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "ABRYSVO, poudre et solvant pour solution injectable. Vaccin du virus respiratoire syncytial (bivalent, recombinant)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BX05"
    },
    {
      "code" : "libelleATC",
      "valueString" : "vaccins du virus respiratoire syncytial"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_60990140"
    }]
  },
  {
    "code" : "3400930302187",
    "display" : "MRESVIA, dispersion injectable en seringue préremplie. Vaccin à ARNm contre le virus respiratoire syncytial - 1 seringue préremplie copolymère de cyclooléfines (COC) de 0,5 mL  dans une alvéole en carton",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890042826"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9004282"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "MRESVIA DISP INJ SRG0,5ML"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "64933425"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "MRESVIA, dispersion injectable en seringue préremplie. Vaccin à ARNm contre le virus respiratoire syncytial"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BX05"
    },
    {
      "code" : "libelleATC",
      "valueString" : "vaccins du virus respiratoire syncytial"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_64933425"
    }]
  },
  {
    "code" : "3400936876415",
    "display" : "VARIVAX, poudre et solvant pour suspension injectable en seringue préremplie. Vaccin varicelleux (vivant) - 1 flacon(s) en verre - 1 seringue(s) préremplie(s) en verre de 0,5 ml sans aiguille attachée avec 2 aiguilles séparées",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3687641"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400892842981"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9284298"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "VARIVAX INJ FL+SRG A/2AIG"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "69201849"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "VARIVAX, poudre et solvant pour suspension injectable en seringue préremplie. Vaccin varicelleux (vivant)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BK01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "varicelle, virus vivant atténué"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_69201849"
    }]
  },
  {
    "code" : "3400936277229",
    "display" : "VARILRIX, poudre et solvant pour solution injectable en seringue préremplie. Vaccin varicelleux (vivant) - 1 flacon(s) en verre - 1 seringue(s) préremplie(s) en verre de 0,5 ml avec 2 aiguille(s)",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3627722"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400892607771"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9260777"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "VARILRIX INJ FL+SRG +2A"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "62521070"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "VARILRIX, poudre et solvant pour solution injectable en seringue préremplie. Vaccin varicelleux (vivant)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BK01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "varicelle, virus vivant atténué"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_62521070"
    }]
  },
  {
    "code" : "3400937593007",
    "display" : "ZOSTAVAX, poudre et solvant pour suspension injectable en seringue préremplie. Vaccin zona (vivant atténué) - 1 flacon(s) en verre - 1 seringue(s) préremplie(s) en verre avec 2 aiguille(s)",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3759300"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400894091622"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9409162"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "ZOSTAVAX INJ FL+SRG +2AIG"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "60956323"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "ZOSTAVAX, poudre et solvant pour suspension injectable en seringue préremplie. Vaccin zona (vivant atténué)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BK02"
    },
    {
      "code" : "libelleATC",
      "valueString" : "zona, virus vivant atténué"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_60956323"
    }]
  },
  {
    "code" : "3400930141861",
    "display" : "SHINGRIX, poudre et suspension pour suspension injectable. Vaccin zona (recombinant, avec adjuvant) - 1 flacon en verre de 50 microgrammes de poudre  - 1 flacon en verre de 0,5 ml de suspension",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890031455"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9003145"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "SHINGRIX INJ FL+FL"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "62887096"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "SHINGRIX, poudre et suspension pour suspension injectable. Vaccin zona (recombinant, avec adjuvant)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BK03"
    },
    {
      "code" : "libelleATC",
      "valueString" : "zona, antigène purifié"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_62887096"
    }]
  },
  {
    "code" : "3400937713016",
    "display" : "GARDASIL, suspension injectable en seringue préremplie. Vaccin Papillomavirus Humain [Types 6, 11, 16, 18] (Recombinant, adsorbé) - 1 seringue(s) préremplie(s) en verre avec 2 aiguille(s) de 0,5 ml",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3771301"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400893009109"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9300910"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "GARDASIL INJ SRG A/2AIG"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "69604608"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "GARDASIL, suspension injectable en seringue préremplie. Vaccin Papillomavirus Humain [Types 6, 11, 16, 18] (Recombinant, adsorbé)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BM01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "Papillomavirus (types humains 6,11,16,18)"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_69604608"
    }]
  },
  {
    "code" : "3400930056202",
    "display" : "GARDASIL 9, suspension injectable en seringue préremplie. Vaccin Papillomavirus Humain 9-valent (Recombinant, adsorbé) - 1 seringue(s) préremplie(s) en verre de 0,5 ml avec aiguille(s)",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400894258827"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9425882"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "GARDASIL 9 INJ SRG0,5ML +2AIG"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "65017887"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "GARDASIL 9, suspension injectable en seringue préremplie. Vaccin Papillomavirus Humain 9-valent (Recombinant, adsorbé)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BM03"
    },
    {
      "code" : "libelleATC",
      "valueString" : "Papillomavirus (types humains 6, 11, 16, 18, 31, 33, 45, 52,58)"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_65017887"
    }]
  },
  {
    "code" : "3400938164237",
    "display" : "CERVARIX, suspension injectable en seringue pré-remplie .Vaccin Papillomavirus Humain [Types 16, 18] (Recombinant, avec adjuvant, adsorbé) - 1 seringue(s) préremplie(s) en verre de 0,5 ml avec 1 aiguille(s)",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3816423"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400893111963"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9311196"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "CERVARIX INJ SRG0,5ML +1AIG"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "64098181"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "CERVARIX, suspension injectable en seringue pré-remplie .Vaccin Papillomavirus Humain [Types 16, 18] (Recombinant, avec adjuvant, adsorbé)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BM02"
    },
    {
      "code" : "libelleATC",
      "valueString" : "Papillomavirus (types humains 16,18)"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_64098181"
    }]
  },
  {
    "code" : "3400936993488",
    "display" : "STAMARIL, poudre et solvant pour suspension injectable en seringue préremplie. Vaccin de la fièvre jaune (Vivant) - 10 flacon(s) en verre de 1 dose(s) - 10 seringue(s) préremplie(s) en verre de 0,5 ml avec deux aiguille(s) séparées",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3699348"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400893046708"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9304670"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "STAMARIL INJ FL+SRG A/2AIG"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "62102962"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "STAMARIL, poudre et solvant pour suspension injectable en seringue préremplie. Vaccin de la fièvre jaune (Vivant)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BL01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "fièvre jaune, virus vivant atténué"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_62102962"
    }]
  },
  {
    "code" : "3400936993310",
    "display" : "STAMARIL, poudre et solvant pour suspension injectable en seringue préremplie. Vaccin de la fièvre jaune (Vivant) - 1 flacon(s) en verre de 1 dose(s) - 1 seringue(s) préremplie(s) en verre de 0,5 ml avec deux aiguille(s) séparées",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3699331"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400893046708"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9304670"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "STAMARIL INJ FL+SRG A/2AIG"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "62102962"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "STAMARIL, poudre et solvant pour suspension injectable en seringue préremplie. Vaccin de la fièvre jaune (Vivant)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BL01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "fièvre jaune, virus vivant atténué"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_62102962"
    }]
  },
  {
    "code" : "3400935081018",
    "display" : "STAMARIL, poudre et solvant pour suspension injectable en seringue préremplie. Vaccin de la fièvre jaune (Vivant) - 1 flacon(s) en verre de 1 dose(s) - 1 seringue(s) préremplie(s) en verre de 0,5 ml avec 1 aiguille(s) attachée",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3508101"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400892309194"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9230919"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "STAMARIL INJ FL+SRG A/1AIG AT"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "62102962"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "STAMARIL, poudre et solvant pour suspension injectable en seringue préremplie. Vaccin de la fièvre jaune (Vivant)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BL01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "fièvre jaune, virus vivant atténué"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_62102962"
    }]
  },
  {
    "code" : "3400936122123",
    "display" : "STAMARIL, poudre et solvant pour suspension injectable en récipient multidose, Vaccin de la fièvre jaune (vivant) - 10 flacon(s) en verre de 10 dose(s) - 10 flacon(s) en verre de 5 mL",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3612212"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400890030298"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9003029"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "STAMARIL INJ FL+FL"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "68844917"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "STAMARIL, poudre et solvant pour suspension injectable en récipient multidose, Vaccin de la fièvre jaune (vivant)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BL01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "fièvre jaune, virus vivant atténué"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_68844917"
    }]
  },
  {
    "code" : "3400939020167",
    "display" : "ROTARIX, suspension buvable en applicateur prérempli pour administration orale. Vaccin à rotavirus, vivant - 1 applicateur pour administration orale en verre de 1,5 ml",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3902016"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400893843505"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9384350"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "ROTARIX BUV APPLCT.1,5ML"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "60755263"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "ROTARIX, suspension buvable en applicateur prérempli pour administration orale. Vaccin à rotavirus, vivant"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BH01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "Rotavirus, virus vivant atténué"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_60755263"
    }]
  },
  {
    "code" : "3400939020228",
    "display" : "ROTARIX, suspension buvable en tube souple. Vaccin à rotavirus, vivant - 1 tube souple polyéthylène de 1,5 mL",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3902022"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400890007641"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9000764"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "ROTARIX BUV TB1,5ML"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "60886387"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "ROTARIX, suspension buvable en tube souple. Vaccin à rotavirus, vivant"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BH01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "Rotavirus, virus vivant atténué"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_60886387"
    }]
  },
  {
    "code" : "3400937622363",
    "display" : "ROTATEQ, solution buvable. Vaccin Rotavirus (vivant, oral) - 1 tube unidose souple polyéthylène basse densité (PEBD) suremballée(s)/surpochée(s) de 2 ml",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3762236"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400892938318"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9293831"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "ROTATEQ BUV UNIDOS2ML"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "66396810"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "ROTATEQ, solution buvable. Vaccin Rotavirus (vivant, oral)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BH02"
    },
    {
      "code" : "libelleATC",
      "valueString" : "Rotavirus, virus pentavalent vivant atténué"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_66396810"
    }]
  },
  {
    "code" : "3400933048877",
    "display" : "VACCIN RABIQUE PASTEUR, poudre et solvant pour suspension injectable. Vaccin rabique, inactivé - 1 flacon(s) en verre - 1 seringue(s) préremplie(s) en verre de 0,5 ml avec aiguille(s) avec protège-aiguille",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3304887"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400891273632"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9127363"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "PASTEUR VAC RABIQ.VERO FL+S."
    },
    {
      "code" : "codeCIS",
      "valueCode" : "67718545"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "VACCIN RABIQUE PASTEUR, poudre et solvant pour suspension injectable. Vaccin rabique, inactivé"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BG01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "rage, virus entier inactivé"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_67718545"
    }]
  },
  {
    "code" : "3400930071595",
    "display" : "RABIPUR, poudre et solvant pour solution injectable en seringue préremplie. Vaccin rabique (inactivé) - 1 flacon en verre - 1 seringue préremplie en verre de 1 ml et 2 aiguilles séparées une pour la reconstitution et une pour l’administration",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400894230960"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9423096"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "RABIPUR INJ FL+SRG +AIG"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "66800338"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "RABIPUR, poudre et solvant pour solution injectable en seringue préremplie. Vaccin rabique (inactivé)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BG01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "rage, virus entier inactivé"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_66800338"
    }]
  },
  {
    "code" : "3400930296448",
    "display" : "IXCHIQ, poudre et solvant pour solution injectable. Vaccin contre le chikungunya (vivant) - 1 flacon unidose en verre + 1 seringue préremplie en verre de 0,5 mL",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890042741"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9004274"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "IXCHIQ INJ FL+SRG0,5ML"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "67395234"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "IXCHIQ, poudre et solvant pour solution injectable. Vaccin contre le chikungunya (vivant)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BP01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "chikungunya, virus vivant atténué"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_67395234"
    }]
  },
  {
    "code" : "3400930313398",
    "display" : "VIMKUNYA, suspension injectable en seringue préremplie. Vaccin contre le chikungunya (recombinant, adsorbé) - 1 seringue préremplie en verre de 0,8 mL",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890047777"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9004777"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "VIMKUNYA INJ SRG0,8ML"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "67392551"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "VIMKUNYA, suspension injectable en seringue préremplie. Vaccin contre le chikungunya (recombinant, adsorbé)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BP02"
    },
    {
      "code" : "libelleATC",
      "valueString" : "chikungunya, pseudo-particules virales"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_67392551"
    }]
  },
  {
    "code" : "3400930222256",
    "display" : "VAXZEVRIA, suspension injectable. Vaccin COVID-19 (ChAdOx1-S [recombinant]) - 10 flacons multidoses en verre de 10 doses",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890010047"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9001004"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "VAXZEVRIA VAC COV19 F5ML/10D"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "61875116"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "VAXZEVRIA, suspension injectable. Vaccin COVID-19 (ChAdOx1-S [recombinant])"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BN02"
    },
    {
      "code" : "libelleATC",
      "valueString" : "COVID-19, vecteur viral, non réplicatif"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_61875116"
    }]
  },
  {
    "code" : "3400930222232",
    "display" : "JCOVDEN, suspension injectable Vaccin contre la COVID-19 (Ad26.COV2-S [recombinant]) - 10 flacons multidoses en verre  de 5 doses",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890010566"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9001056"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "JCOVDEN VAC FL2,5ML/5D"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "64798803"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "JCOVDEN, suspension injectable Vaccin contre la COVID-19 (Ad26.COV2-S [recombinant])"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BN02"
    },
    {
      "code" : "libelleATC",
      "valueString" : "COVID-19, vecteur viral, non réplicatif"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_64798803"
    }]
  },
  {
    "code" : "3400930227015",
    "display" : "JCOVDEN, suspension injectable Vaccin contre la COVID-19 (Ad26.COV2-S [recombinant]) - 20 flacons multidoses en verre  de 5 doses",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890010566"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9001056"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "JCOVDEN VAC FL2,5ML/5D"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "64798803"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "JCOVDEN, suspension injectable Vaccin contre la COVID-19 (Ad26.COV2-S [recombinant])"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BN02"
    },
    {
      "code" : "libelleATC",
      "valueString" : "COVID-19, vecteur viral, non réplicatif"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_64798803"
    }]
  },
  {
    "code" : "3400930243404",
    "display" : "COMIRNATY 10 microgrammes/dose, dispersion à diluer pour dispersion injectable.Vaccin à ARNm (à nucléoside modifié) contre la COVID-19 - 10 flacon(s) multidose(s) en verre de 10 dose(s) ( abrogée le 12/12/2024)",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890019033"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9001903"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "COMIRNATY 10µG/D DISP DIL FL"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "69174918"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "COMIRNATY 10 microgrammes/dose, dispersion à diluer pour dispersion injectable.Vaccin à ARNm (à nucléoside modifié) contre la COVID-19"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BN01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "COVID-19, vaccin à ARN"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_69174918"
    }]
  },
  {
    "code" : "3400930264478",
    "display" : "COMIRNATY ORIGINAL/OMICRON BA.4-5 (5/5 microgrammes)/dose, dispersion à diluer pour dispersion injectable. Vaccin à ARNm (à nucléoside modifié) contre la COVID-19 - 10 flacon(s) multidose(s) en verre de 10 dose(s) ( abrogée le 12/12/2024)",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890028448"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9002844"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "COMIRNATY 5/5µG/D BA4-5 10D"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "64089816"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "COMIRNATY ORIGINAL/OMICRON BA.4-5 (5/5 microgrammes)/dose, dispersion à diluer pour dispersion injectable. Vaccin à ARNm (à nucléoside modifié) contre la COVID-19"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BN01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "COVID-19, vaccin à ARN"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_64089816"
    }]
  },
  {
    "code" : "3400930243411",
    "display" : "COMIRNATY 30 microgrammes/dose, dispersion injectable.Vaccin à ARNm (à nucléoside modifié) contre la COVID-19 - 10 flacons multidoses en verre de 6 doses ( abrogée le 12/12/2024)",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890019040"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9001904"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "COMIRNATY 30µG/D DISP INJ F"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "65456578"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "COMIRNATY 30 microgrammes/dose, dispersion injectable.Vaccin à ARNm (à nucléoside modifié) contre la COVID-19"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BN01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "COVID-19, vaccin à ARN"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_65456578"
    }]
  },
  {
    "code" : "3400930299777",
    "display" : "COMIRNATY JN.1 3 microgrammes/dose, dispersion à diluer pour dispersion injectable. Vaccin à ARNm contre la COVID-19 - 10 flacon(s) en verre multidose(s) de 3 dose(s)",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890041720"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9004172"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "COMIRNATY 3µG/D JN.1 FL3D"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "65290793"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "COMIRNATY JN.1 3 microgrammes/dose, dispersion à diluer pour dispersion injectable. Vaccin à ARNm contre la COVID-19"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BN01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "COVID-19, vaccin à ARN"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_65290793"
    }]
  },
  {
    "code" : "3400930259528",
    "display" : "SPIKEVAX BIVALENT ORIGINAL/OMICRON BA.1 (50 microgrammes/50 microgrammes)/ml, dispersion injectable, Vaccin à ARNm contre la COVID-19 - 10 flacon(s) multidose(s) en verre de 5 dose(s)",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890026765"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9002676"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "SPIKEVAX 50/50µG/ML BA1 F5D"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "62609613"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "SPIKEVAX BIVALENT ORIGINAL/OMICRON BA.1 (50 microgrammes/50 microgrammes)/ml, dispersion injectable, Vaccin à ARNm contre la COVID-19"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BN01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "COVID-19, vaccin à ARN"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_62609613"
    }]
  },
  {
    "code" : "3400930299760",
    "display" : "COMIRNATY JN.1 30 microgrammes/dose, dispersion injectable. Vaccin à ARNm contre la COVID-19 - 10 flacon(s) en verre multidose(s) de 6 dose(s)",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890041713"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9004171"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "COMIRNATY 30µG/D JN.1 FL6D"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "64281916"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "COMIRNATY JN.1 30 microgrammes/dose, dispersion injectable. Vaccin à ARNm contre la COVID-19"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BN01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "COVID-19, vaccin à ARN"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_64281916"
    }]
  },
  {
    "code" : "3400930219553",
    "display" : "SPIKEVAX 0,2 mg/mL, dispersion injectable. Vaccin à ARNm contre la COVID-19 - 10 flacon(s) multidose(s) en verre",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890009676"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9000967"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "SPIKEVAX 0,2MG/ML COV19 F10D"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "66689795"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "SPIKEVAX 0,2 mg/mL, dispersion injectable. Vaccin à ARNm contre la COVID-19"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BN01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "COVID-19, vaccin à ARN"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_66689795"
    }]
  },
  {
    "code" : "3400930325506",
    "display" : "COMIRNATY LP.8.1 30 microgrammes/dose, dispersion injectable. Vaccin à ARNm contre la COVID-19 - 10 flacons en verre multidoses de 6 doses, 60 doses",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890051125"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9005112"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "COMIRNATY LP8.1 30µG/D FL6D"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "63466367"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "COMIRNATY LP.8.1 30 microgrammes/dose, dispersion injectable. Vaccin à ARNm contre la COVID-19"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BN01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "COVID-19, vaccin à ARN"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_63466367"
    }]
  },
  {
    "code" : "3400930279076",
    "display" : "COMIRNATY OMICRON XBB.1.5 3 microgrammes/dose, dispersion à diluer pour dispersion injectable. Vaccin à ARNm (à nucléoside modifié) contre la COVID-19 - 10 flacon(s) multidose(s) en verre de 10 dose(s)",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890034869"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9003486"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "COMIRNATY 3µG/D XBB1.5 DISP"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "64995124"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "COMIRNATY OMICRON XBB.1.5 3 microgrammes/dose, dispersion à diluer pour dispersion injectable. Vaccin à ARNm (à nucléoside modifié) contre la COVID-19"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BN01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "COVID-19, vaccin à ARN"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_64995124"
    }]
  },
  {
    "code" : "3400930264058",
    "display" : "COMIRNATY 3 microgrammes/dose, dispersion à diluer pour dispersion injectable.Vaccin à ARNm (à nucléoside modifié) contre la COVID-19 - 10 flacon(s) multidose(s) en verre de 10 dose(s) ( abrogée le 12/12/2024)",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890028295"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9002829"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "COMIRNATY 3µG/D DISP INJ FL"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "63786926"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "COMIRNATY 3 microgrammes/dose, dispersion à diluer pour dispersion injectable.Vaccin à ARNm (à nucléoside modifié) contre la COVID-19"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BN01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "COVID-19, vaccin à ARN"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_63786926"
    }]
  },
  {
    "code" : "3400930299753",
    "display" : "COMIRNATY JN.1 10 microgrammes/dose, dispersion injectable. Vaccin à ARNm contre la COVID-19 - 10 flacon(s) en verre multidose(s) de 6 dose(s)",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890041706"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9004170"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "COMIRNATY 10µG/D JN.1 FL6D"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "64397504"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "COMIRNATY JN.1 10 microgrammes/dose, dispersion injectable. Vaccin à ARNm contre la COVID-19"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BN01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "COVID-19, vaccin à ARN"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_64397504"
    }]
  },
  {
    "code" : "3400930262009",
    "display" : "COMIRNATY ORIGINAL/OMICRON BA.4-5 (15/15 microgrammes)/dose, dispersion injectable. Vaccin à ARNm (à nucléoside modifié) contre la COVID-19 - 10 flacon(s) multidose(s) en verre de 6 dose(s) ( abrogée le 12/12/2024)",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890026901"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9002690"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "COMIRNATY 15/15µG/D BA4-5 6D"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "65590890"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "COMIRNATY ORIGINAL/OMICRON BA.4-5 (15/15 microgrammes)/dose, dispersion injectable. Vaccin à ARNm (à nucléoside modifié) contre la COVID-19"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BN01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "COVID-19, vaccin à ARN"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_65590890"
    }]
  },
  {
    "code" : "3400930279038",
    "display" : "COMIRNATY OMICRON XBB.1.5 30 microgrammes/dose, dispersion injectable. Vaccin à ARNm (à nucléoside modifié) contre la COVID-19 - 10 flacons multidoses en verre de 6 doses",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890034876"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9003487"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "COMIRNATY 30µG/D XBB1.5 FL6D"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "64548397"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "COMIRNATY OMICRON XBB.1.5 30 microgrammes/dose, dispersion injectable. Vaccin à ARNm (à nucléoside modifié) contre la COVID-19"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BN01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "COVID-19, vaccin à ARN"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_64548397"
    }]
  },
  {
    "code" : "3400930325568",
    "display" : "COMIRNATY LP.8.1 3 microgrammes/dose, dispersion à diluer pour dispersion injectable. Vaccin à ARNm contre la COVID-19 - 10 flacons en verre multidoses de 3 doses - 30 doses",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890051101"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9005110"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "COMIRNATY LP8.1 3µG/D FL3D"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "64208590"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "COMIRNATY LP.8.1 3 microgrammes/dose, dispersion à diluer pour dispersion injectable. Vaccin à ARNm contre la COVID-19"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BN01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "COVID-19, vaccin à ARN"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_64208590"
    }]
  },
  {
    "code" : "3400930325544",
    "display" : "COMIRNATY LP.8.1 10 microgrammes/dose, dispersion injectable. Vaccin à ARNm contre la COVID-19 - 10 flacons multidoses en verre de 6 doses - 60 doses",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890051095"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9005109"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "COMIRNATY LP8.1 10µG/D FL6D"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "67364121"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "COMIRNATY LP.8.1 10 microgrammes/dose, dispersion injectable. Vaccin à ARNm contre la COVID-19"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BN01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "COVID-19, vaccin à ARN"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_67364121"
    }]
  },
  {
    "code" : "3400930266472",
    "display" : "SPIKEVAX BIVALENT ORIGINAL/OMICRON BA.4-5 25 microgrammes/25 microgrammes, dispersion injectable. Vaccin à ARNm contre la COVID-19 - 10 flacon(s) unidose(s) en verre (10 doses)",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890029155"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9002915"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "SPIKEVAX 25/25µG/ML BA4-5 1D"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "69556437"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "SPIKEVAX BIVALENT ORIGINAL/OMICRON BA.4-5 25 microgrammes/25 microgrammes, dispersion injectable. Vaccin à ARNm contre la COVID-19"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BN01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "COVID-19, vaccin à ARN"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_69556437"
    }]
  },
  {
    "code" : "3400930279069",
    "display" : "COMIRNATY OMICRON XBB.1.5 10 microgrammes/dose, dispersion injectable. Vaccin à ARNm (à nucléoside modifié) contre la COVID-19 - 10 flacons multidoses en verre de 6 doses",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890034852"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9003485"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "COMIRNATY 10µG/D XBB1.5 FL6D"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "60327063"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "COMIRNATY OMICRON XBB.1.5 10 microgrammes/dose, dispersion injectable. Vaccin à ARNm (à nucléoside modifié) contre la COVID-19"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BN01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "COVID-19, vaccin à ARN"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_60327063"
    }]
  },
  {
    "code" : "3400930261729",
    "display" : "COMIRNATY ORIGINAL/OMICRON BA.1 (15/15 microgrammes)/dose, dispersion injectable. Vaccin à ARNm (à nucléoside modifié) contre la COVID-19 - 10 flacon(s) multidose(s) en verre de 6 dose(s) ( abrogée le 03/07/2024)",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890026758"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9002675"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "COMIRNATY 15/15µG/D BA1 F6D"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "69401508"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "COMIRNATY ORIGINAL/OMICRON BA.1 (15/15 microgrammes)/dose, dispersion injectable. Vaccin à ARNm (à nucléoside modifié) contre la COVID-19"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BN01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "COVID-19, vaccin à ARN"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_69401508"
    }]
  },
  {
    "code" : "3400930218662",
    "display" : "COMIRNATY 30 microgrammes/dose, dispersion à diluer pour dispersion injectable. Vaccin à ARNm (à nucléoside modifié) contre la COVID-19 - 195 flacons multidoses en verre de 6 doses ( abrogée le 03/07/2024)",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890009454"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9000945"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "COMIRNATY 30µG/D DISP DIL FL"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "60495328"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "COMIRNATY 30 microgrammes/dose, dispersion à diluer pour dispersion injectable. Vaccin à ARNm (à nucléoside modifié) contre la COVID-19"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BN01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "COVID-19, vaccin à ARN"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_60495328"
    }]
  },
  {
    "code" : "3400930277409",
    "display" : "NUVAXOVID XBB.1.5, dispersion injectable. Vaccin contre la COVID-19 (recombinant, avec adjuvant) - 2 flacons multidoses en verre de 2,5 mL de 5 doses (10 doses)",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890036153"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9003615"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "NUVAXOVID XBB1,5 DISP2,5ML/5D"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "65689785"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "NUVAXOVID XBB.1.5, dispersion injectable. Vaccin contre la COVID-19 (recombinant, avec adjuvant)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BN04"
    },
    {
      "code" : "libelleATC",
      "valueString" : "COVID-19, sous-unité protéique"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_65689785"
    }]
  },
  {
    "code" : "3400930264157",
    "display" : "VIDPREVTYN BETA, solution et émulsion pour émulsion injectable. Vaccin contre la COVID-19 (recombinant avec adjuvant) - 10 flacon(s) multidose(s) de 10 doses  en verre de 2,5 mL- 10 flacon(s) multidose(s) de 10 doses en verre de 2,5 mL (100 doses),",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890028127"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9002812"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "VIDPREVTYN BETA INJ F+F10D"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "67734275"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "VIDPREVTYN BETA, solution et émulsion pour émulsion injectable. Vaccin contre la COVID-19 (recombinant avec adjuvant)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BN04"
    },
    {
      "code" : "libelleATC",
      "valueString" : "COVID-19, sous-unité protéique"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_67734275"
    }]
  },
  {
    "code" : "3400930245774",
    "display" : "NUVAXOVID, dispersion injectable. Vaccin contre la COVID-19 (recombinant, avec adjuvant) - 10 flacons multidoses en verre de 5 mL de 10 doses (100 doses)",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890019903"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9001990"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "NUVAXOVID DISP INJ F5ML/10D"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "69544189"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "NUVAXOVID, dispersion injectable. Vaccin contre la COVID-19 (recombinant, avec adjuvant)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BN04"
    },
    {
      "code" : "libelleATC",
      "valueString" : "COVID-19, sous-unité protéique"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_69544189"
    }]
  },
  {
    "code" : "3400935676870",
    "display" : "TWINRIX ENFANT, suspension injectable en seringue préremplie. Vaccin de l'hépatite A (inactivé) et de l'hépatite B (ADNr) (HAB) (adsorbé) - 1 seringue(s) préremplie(s) de 0,5 ml avec aiguille(s)",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3567687"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400892347974"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9234797"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "TWINRIX ENF INJ SRG+AIG"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "64737775"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "TWINRIX ENFANT, suspension injectable en seringue préremplie. Vaccin de l'hépatite A (inactivé) et de l'hépatite B (ADNr) (HAB) (adsorbé)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BC20"
    },
    {
      "code" : "libelleATC",
      "valueString" : "associations (vaccins des hépatites)"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_64737775"
    }]
  },
  {
    "code" : "3400935676931",
    "display" : "TWINRIX ADULTE, suspension injectable en seringue préremplie. Vaccin de l'hépatite A (inactivé) et de l'hépatite B (ADNr) (HAB) (adsorbé) - 1 seringue(s) préremplie(s) avec aiguille(s) de 1  ml",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3567693"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400892347806"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9234780"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "TWINRIX AD. INJ SRG+AIG"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "65991659"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "TWINRIX ADULTE, suspension injectable en seringue préremplie. Vaccin de l'hépatite A (inactivé) et de l'hépatite B (ADNr) (HAB) (adsorbé)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BC20"
    },
    {
      "code" : "libelleATC",
      "valueString" : "associations (vaccins des hépatites)"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_65991659"
    }]
  },
  {
    "code" : "3400936924642",
    "display" : "HBVAXPRO 10 microgrammes, suspension injectable en seringue préremplie. Vaccin de l'hépatite B (ADNr) - 1 seringue(s) préremplie(s) en verre de 1 ml avec 2 aiguille(s)",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3692464"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400892892900"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9289290"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "HBVAXPRO 10µG SRG1ML A/2AIG"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "64646891"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "HBVAXPRO 10 microgrammes, suspension injectable en seringue préremplie. Vaccin de l'hépatite B (ADNr)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BC01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "hépatite B, antigène purifié"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_64646891"
    }]
  },
  {
    "code" : "3400935166906",
    "display" : "ENGERIX B 20 microgrammes/1 mL, suspension injectable en seringue préremplie. Vaccin de l'hépatite B (ADNr), (adsorbé) (VHB) - 1 seringue(s) préremplie(s) en verre de 1 ml avec aiguille(s)",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3516690"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400892258126"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9225812"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "ENGERIX B 20µG SRG.BACK.1ML"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "62279329"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "ENGERIX B 20 microgrammes/1 mL, suspension injectable en seringue préremplie. Vaccin de l'hépatite B (ADNr), (adsorbé) (VHB)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BC01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "hépatite B, antigène purifié"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_62279329"
    }]
  },
  {
    "code" : "3400936924291",
    "display" : "HBVAXPRO 5 microgrammes, suspension injectable en seringue préremplie. Vaccin de l'hépatite B (ADNr) - 1 seringue(s) préremplie(s) en verre de 0,5 ml avec 2 aiguille(s)",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3692429"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400892893099"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9289309"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "HBVAXPRO 5µG SRG0,5ML A/2A"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "69352630"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "HBVAXPRO 5 microgrammes, suspension injectable en seringue préremplie. Vaccin de l'hépatite B (ADNr)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BC01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "hépatite B, antigène purifié"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_69352630"
    }]
  },
  {
    "code" : "3400935167095",
    "display" : "ENGERIX B 10 microgrammes/0,5 mL, suspension injectable en seringue préremplie. Vaccin de l'hépatite B (ADNr), (adsorbé) (VHB) - 1 seringue(s) préremplie(s) en verre de 0,5 ml avec aiguille(s)",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3516709"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400892258065"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9225806"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "ENGERIX B 10µG SRG.BACK.0,5ML"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "65782652"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "ENGERIX B 10 microgrammes/0,5 mL, suspension injectable en seringue préremplie. Vaccin de l'hépatite B (ADNr), (adsorbé) (VHB)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BC01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "hépatite B, antigène purifié"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_65782652"
    }]
  },
  {
    "code" : "3400935676580",
    "display" : "HBVAXPRO 40 microgrammes, suspension injectable. Vaccin de l'hépatite B (ADNr) - 1 flacon(s) en verre de 1  ml",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3567658"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400892308944"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9230894"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "HBVAXPRO 40µG INJ FL1ML"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "64757607"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "HBVAXPRO 40 microgrammes, suspension injectable. Vaccin de l'hépatite B (ADNr)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BC01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "hépatite B, antigène purifié"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_64757607"
    }]
  },
  {
    "code" : "3400937082020",
    "display" : "AVAXIM 160 U, suspension injectable en seringue préremplie. Vaccin de l'hépatite A (inactivé, adsorbé) - 1 seringue(s) préremplie(s) en verre de 0,5 ml, avec 2 aiguille(s) séparées",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3708202"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400893011058"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9301105"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "AVAXIM 160U INJ S0,5ML A/2A"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "62756524"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "AVAXIM 160 U, suspension injectable en seringue préremplie. Vaccin de l'hépatite A (inactivé, adsorbé)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BC02"
    },
    {
      "code" : "libelleATC",
      "valueString" : "hépatite A, virus entier inactivé"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_62756524"
    }]
  },
  {
    "code" : "3400934166525",
    "display" : "AVAXIM 160 U, suspension injectable en seringue préremplie. Vaccin de l'hépatite A (inactivé, adsorbé) - 1 seringue(s) préremplie(s) en verre de 0,5 ml avec 1 aiguille(s) attachée",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3416652"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400891836400"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9183640"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "AVAXIM 160U INJ SRG0,5ML"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "62756524"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "AVAXIM 160 U, suspension injectable en seringue préremplie. Vaccin de l'hépatite A (inactivé, adsorbé)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BC02"
    },
    {
      "code" : "libelleATC",
      "valueString" : "hépatite A, virus entier inactivé"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_62756524"
    }]
  },
  {
    "code" : "3400934760457",
    "display" : "HAVRIX NOURRISSONS ET ENFANTS 720 U/0,5 mL, suspension injectable en seringue préremplie. Vaccin de l'hépatite A (inactivé, adsorbé) - 1 seringue(s) préremplie(s) en verre de 0,5 ml avec aiguille(s)",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3476045"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400892065717"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9206571"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "HAVRIX 720 ENF INJ SRG0,5ML"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "60152436"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "HAVRIX NOURRISSONS ET ENFANTS 720 U/0,5 mL, suspension injectable en seringue préremplie. Vaccin de l'hépatite A (inactivé, adsorbé)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BC02"
    },
    {
      "code" : "libelleATC",
      "valueString" : "hépatite A, virus entier inactivé"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_60152436"
    }]
  },
  {
    "code" : "3400933775155",
    "display" : "HAVRIX 1440 U/1 mL ADULTES, suspension injectable en seringue préremplie. Vaccin de l'hépatite A (inactivé, adsorbé) - 1 seringue(s) préremplie(s) en verre de 1 ml avec aiguille(s)",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3377515"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400891690316"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9169031"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "HAVRIX 1440 AD. INJ SRG1ML"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "60386414"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "HAVRIX 1440 U/1 mL ADULTES, suspension injectable en seringue préremplie. Vaccin de l'hépatite A (inactivé, adsorbé)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BC02"
    },
    {
      "code" : "libelleATC",
      "valueString" : "hépatite A, virus entier inactivé"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_60386414"
    }]
  },
  {
    "code" : "3400935677242",
    "display" : "AVAXIM 80 U PEDIATRIQUE, suspension injectable en seringue préremplie. Vaccin de l'hépatite A (inactivé, adsorbé) - 1 seringue(s) préremplie(s) en verre de 0,5 ml avec une aiguille attachée",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3567724"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400893547458"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9354745"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "AVAXIM 80U INJ SRG0,5ML A/A"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "63777215"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "AVAXIM 80 U PEDIATRIQUE, suspension injectable en seringue préremplie. Vaccin de l'hépatite A (inactivé, adsorbé)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BC02"
    },
    {
      "code" : "libelleATC",
      "valueString" : "hépatite A, virus entier inactivé"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_63777215"
    }]
  },
  {
    "code" : "3400938309959",
    "display" : "VAQTA 50 U/1 ml, suspension injectable en seringue préremplie. Vaccin de l’hépatite A, inactivé, adsorbé. Pour adultes - 1 seringue(s) préremplie(s) en verre de 1 ml munie d'un bouchon-piston, d'un protège-embout, avec 2 aiguille(s) séparées",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3830995"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400894108283"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9410828"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "VAQTA 50U/1ML INJ SRG +2AIG"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "62087670"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "VAQTA 50 U/1 ml, suspension injectable en seringue préremplie. Vaccin de l’hépatite A, inactivé, adsorbé. Pour adultes"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BC02"
    },
    {
      "code" : "libelleATC",
      "valueString" : "hépatite A, virus entier inactivé"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_62087670"
    }]
  },
  {
    "code" : "3400930926758",
    "display" : "ROUVAX, poudre et solvant pour suspension injectable. Vaccin rougeoleux vivant - 1 flacon(s) en verre jaune(brun) de 1 dose(s) - 1 seringue(s) préremplie(s) en verre de 0,5 ml",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3092675"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400890812184"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9081218"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "ROUVAX FL+SERING"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "60043248"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "ROUVAX, poudre et solvant pour suspension injectable. Vaccin rougeoleux vivant"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BD01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "rougeole, virus vivant atténué"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_60043248"
    }]
  },
  {
    "code" : "3400935137340",
    "display" : "PRIORIX, poudre et solvant pour solution injectable en seringue préremplie. Vaccin rougeoleux, des oreillons et rubéoleux vivant - 1 flacon(s) en verre de 1  dose(s) - 1 seringue(s) préremplie(s) en verre de 0,5  ml avec 2 aiguille(s)",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3513734"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400892135946"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9213594"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "PRIORIX INJ FL+SRG +2AIG"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "61896473"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "PRIORIX, poudre et solvant pour solution injectable en seringue préremplie. Vaccin rougeoleux, des oreillons et rubéoleux vivant"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BD52"
    },
    {
      "code" : "libelleATC",
      "valueString" : "rougeole en association aux oreillons et à la rubéole, virus vivants atténués"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_61896473"
    }]
  },
  {
    "code" : "3400937328210",
    "display" : "M-M-RVAXPRO poudre et solvant pour suspension injectable en seringue préremplie.Vaccin rougeoleux, des oreillons, et rubéoleux (vivant). - 1 flacon(s) en verre - 1 seringue(s) préremplie(s) en verre avec 2 aiguille(s)",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3732821"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400893104699"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9310469"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "M-M-RVAXPRO INJ FL+SRG +2AIG"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "64269668"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "M-M-RVAXPRO poudre et solvant pour suspension injectable en seringue préremplie.Vaccin rougeoleux, des oreillons, et rubéoleux (vivant)."
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BD52"
    },
    {
      "code" : "libelleATC",
      "valueString" : "rougeole en association aux oreillons et à la rubéole, virus vivants atténués"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_64269668"
    }]
  },
  {
    "code" : "3400937327848",
    "display" : "M-M-RVAXPRO, poudre et solvant pour suspension injectable. Vaccin rougeoleux, des oreillons, et rubéoleux (vivant) - 1 flacon(s) en verre - 1 flacon(s) en verre",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3732784"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400893104521"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9310452"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "M-M-RVAXPRO INJ FL+FL"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "65194581"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "M-M-RVAXPRO, poudre et solvant pour suspension injectable. Vaccin rougeoleux, des oreillons, et rubéoleux (vivant)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BD52"
    },
    {
      "code" : "libelleATC",
      "valueString" : "rougeole en association aux oreillons et à la rubéole, virus vivants atténués"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_65194581"
    }]
  },
  {
    "code" : "3400930198391",
    "display" : "ENCEPUR 1,5 microgrammes/0,5 ml, suspension injectable en seringue préremplie. Vaccin de l'encéphalite à tiques (inactivé, adsorbé) - 1 seringue(s) préremplie(s) en verre de 0,5 ml avec aiguille(s) séparée",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890004053"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9000405"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "ENCEPUR 1,5µG/0,5ML INJ SRG AS"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "69431992"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "ENCEPUR 1,5 microgrammes/0,5 ml, suspension injectable en seringue préremplie. Vaccin de l'encéphalite à tiques (inactivé, adsorbé)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BA01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "encéphalite transmise par les tiques, virus entier inactivé"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_69431992"
    }]
  },
  {
    "code" : "3400936774537",
    "display" : "ENCEPUR 1,5 microgrammes/0,5 ml, suspension injectable en seringue préremplie. Vaccin de l'encéphalite à tiques (inactivé, adsorbé) - 1 seringue(s) préremplie(s) en verre de 0,5 ml avec aiguille attachée",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3677453"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400893318331"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9331833"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "ENCEPUR 1,5µG/0,5ML INJ SRG AA"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "69431992"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "ENCEPUR 1,5 microgrammes/0,5 ml, suspension injectable en seringue préremplie. Vaccin de l'encéphalite à tiques (inactivé, adsorbé)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BA01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "encéphalite transmise par les tiques, virus entier inactivé"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_69431992"
    }]
  },
  {
    "code" : "3400927841705",
    "display" : "TICOVAC 0,5 ml ADULTES, suspension injectable en seringue préremplie. Vaccin de l'encéphalite à tiques (virus entier inactivé) - 1 seringue(s) préremplie(s) en verre de 0,5 ml avec aiguille(s) séparée par seringue",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "2784170"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400894140740"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9414074"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "TICOVAC 0,5ML AD. S/A SRG"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "69663909"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "TICOVAC 0,5 ml ADULTES, suspension injectable en seringue préremplie. Vaccin de l'encéphalite à tiques (virus entier inactivé)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BA01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "encéphalite transmise par les tiques, virus entier inactivé"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_69663909"
    }]
  },
  {
    "code" : "3400936774827",
    "display" : "TICOVAC 0,25 ml ENFANTS, suspension injectable en seringue préremplie. Vaccin de l'encéphalite à tiques (virus entier inactivé) - 1 seringue(s) préremplie(s) en verre de 0,25 ml avec aiguille(s) séparée par seringue",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3677482"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400894140689"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9414068"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "TICOVAC 0,25ML ENF S/A SRG"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "61440306"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "TICOVAC 0,25 ml ENFANTS, suspension injectable en seringue préremplie. Vaccin de l'encéphalite à tiques (virus entier inactivé)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BA01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "encéphalite transmise par les tiques, virus entier inactivé"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_61440306"
    }]
  },
  {
    "code" : "3400939395975",
    "display" : "IXIARO, suspension injectable. Vaccin de l'encéphalite japonaise (inactivé, adsorbé) - 1 seringue(s) préremplie(s) en verre de 0,5 ml",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3939597"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400893319970"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9331997"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "IXIARO INJ SRG0,5ML S/AIG"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "62816512"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "IXIARO, suspension injectable. Vaccin de l'encéphalite japonaise (inactivé, adsorbé)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BA02"
    },
    {
      "code" : "libelleATC",
      "valueString" : "encéphalite japonaise, virus entier inactivé"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_62816512"
    }]
  },
  {
    "code" : "3400932575503",
    "display" : "IMOVAX POLIO, suspension injectable en seringue préremplie. Vaccin poliomyélitique (inactivé) - 1 seringue(s) pré-remplie(s) en verre de 0,5 ml",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3257550"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400892031767"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9203176"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "IMOVAX POLIO SRG0,5ML"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "63513354"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "IMOVAX POLIO, suspension injectable en seringue préremplie. Vaccin poliomyélitique (inactivé)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BF03"
    },
    {
      "code" : "libelleATC",
      "valueString" : "poliomyélite, virus entier trivalent inactivé"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_63513354"
    }]
  },
  {
    "code" : "3400930306000",
    "display" : "VAXIGRIP suspension injectable en seringue préremplie. Vaccin grippal trivalent (inactivé, à virion fragmenté) - 1 seringue préremplie avec aiguille en verre de 0,5 mL",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890047203"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9004720"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "VAXIGRIP TRI SRG0,5ML A/AIG"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "69675854"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "VAXIGRIP suspension injectable en seringue préremplie. Vaccin grippal trivalent (inactivé, à virion fragmenté)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BB02"
    },
    {
      "code" : "libelleATC",
      "valueString" : "grippe, virus inactivé, fragmenté ou antigène de surface"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_69675854"
    }]
  },
  {
    "code" : "3400930296165",
    "display" : "INFLUVAC, suspension injectable en seringue préremplie. Vaccin grippal inactivé à antigènes de surface - 1 seringue(s) préremplie(s) en verre de 0,5 ml avec aiguille(s)",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890046831"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9004683"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "INFLUVAC INJ SRG0,5ML A/AIG"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "63156183"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "INFLUVAC, suspension injectable en seringue préremplie. Vaccin grippal inactivé à antigènes de surface"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BB02"
    },
    {
      "code" : "libelleATC",
      "valueString" : "grippe, virus inactivé, fragmenté ou antigène de surface"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_63156183"
    }]
  },
  {
    "code" : "3400930304716",
    "display" : "FLUAD suspension injectable en seringue préremplie.Vaccin antigrippal (antigènes de surface, inactivé, avec adjuvant) - 1 seringue préremplie en verre de 0,5 mL avec aiguille",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890046602"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9004660"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "FLUAD INJ SRG0,5ML +AIG"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "64090291"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "FLUAD suspension injectable en seringue préremplie.Vaccin antigrippal (antigènes de surface, inactivé, avec adjuvant)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BB02"
    },
    {
      "code" : "libelleATC",
      "valueString" : "grippe, virus inactivé, fragmenté ou antigène de surface"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_64090291"
    }]
  },
  {
    "code" : "3400933385507",
    "display" : "IMMUGRIP, suspension injectable en seringue préremplie. Vaccin grippal (inactivé, à virion fragmenté) - 1 seringue(s) préremplie(s) en verre de 0,5 ml",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3338550"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400891502442"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9150244"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "IMMUGRIP INJ SRG0,5ML"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "65393793"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "IMMUGRIP, suspension injectable en seringue préremplie. Vaccin grippal (inactivé, à virion fragmenté)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BB02"
    },
    {
      "code" : "libelleATC",
      "valueString" : "grippe, virus inactivé, fragmenté ou antigène de surface"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_65393793"
    }]
  },
  {
    "code" : "3400930067727",
    "display" : "VAXIGRIPTETRA, suspension injectable en seringue préremplie. Vaccin grippal quadrivalent (inactivé, à virion fragmenté) - 1 seringue(s) préremplie(s) en verre de 0,5 ml avec aiguille(s) attachée",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400894329657"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9432965"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "VAXIGRIPTETRA S0,5ML A/AA"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "61402736"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "VAXIGRIPTETRA, suspension injectable en seringue préremplie. Vaccin grippal quadrivalent (inactivé, à virion fragmenté)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BB02"
    },
    {
      "code" : "libelleATC",
      "valueString" : "grippe, virus inactivé, fragmenté ou antigène de surface"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_61402736"
    }]
  },
  {
    "code" : "3400930205402",
    "display" : "EFLUELDA TETRA, suspension injectable en seringue préremplie Vaccin grippal quadrivalent (inactivé, à virion fragmenté), 60 microgrammes HA/souche - 1 seringue préremplie en verre de 0,7 ml avec aiguille séparée, munie d’un bouchon-piston (Bromobutyle) et d’un capuchon de protection",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890004602"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9000460"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "EFLUELDA TETRA INJ S0,7ML A/A"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "67823603"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "EFLUELDA TETRA, suspension injectable en seringue préremplie Vaccin grippal quadrivalent (inactivé, à virion fragmenté), 60 microgrammes HA/souche"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BB02"
    },
    {
      "code" : "libelleATC",
      "valueString" : "grippe, virus inactivé, fragmenté ou antigène de surface"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_67823603"
    }]
  },
  {
    "code" : "3400930304686",
    "display" : "FLUCELVAX suspension injectable en seringue préremplie. Vaccin antigrippal inactivé (antigène de surface, préparé sur cultures cellulaires) - 1 seringue préremplie en verre de 0,5 mL avec aiguille",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890044318"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9004431"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "FLUCELVAX INJ SRG0,5ML +AIG"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "62752472"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "FLUCELVAX suspension injectable en seringue préremplie. Vaccin antigrippal inactivé (antigène de surface, préparé sur cultures cellulaires)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BB02"
    },
    {
      "code" : "libelleATC",
      "valueString" : "grippe, virus inactivé, fragmenté ou antigène de surface"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_62752472"
    }]
  },
  {
    "code" : "3400930117712",
    "display" : "INFLUVAC TETRA, suspension injectable en seringue préremplie. Vaccin grippal inactivé à antigènes de surface - 1 seringue(s) préremplie(s) en verre de 0,5 ml avec aiguille(s)",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400894338703"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9433870"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "INFLUVAC TETRA SRG0,5ML A/AIG"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "60716805"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "INFLUVAC TETRA, suspension injectable en seringue préremplie. Vaccin grippal inactivé à antigènes de surface"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BB02"
    },
    {
      "code" : "libelleATC",
      "valueString" : "grippe, virus inactivé, fragmenté ou antigène de surface"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_60716805"
    }]
  },
  {
    "code" : "3400930305010",
    "display" : "EFLUELDA, suspension injectable en seringue préremplie.Vaccin grippal trivalent (inactivé, à virion fragmenté), 60 microgrammes HA/souche - 1 seringue préremplie en verre de 0,5 mL avec aiguille",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400890049139"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9004913"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "EFLUELDA INJ SRG0,5ML A/A"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "62048742"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "EFLUELDA, suspension injectable en seringue préremplie.Vaccin grippal trivalent (inactivé, à virion fragmenté), 60 microgrammes HA/souche"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BB02"
    },
    {
      "code" : "libelleATC",
      "valueString" : "grippe, virus inactivé, fragmenté ou antigène de surface"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_62048742"
    }]
  },
  {
    "code" : "3400930029220",
    "display" : "FLUARIXTETRA, suspension injectable en seringue préremplie. Vaccin grippal inactivé à virion fragmenté - 1 seringue(s) préremplie(s) en verre de 0,5 ml avec 2 aiguilles",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400894212461"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9421246"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "FLUARIXTETRA INJ SRG0,5ML +2A"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "62464573"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "FLUARIXTETRA, suspension injectable en seringue préremplie. Vaccin grippal inactivé à virion fragmenté"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BB02"
    },
    {
      "code" : "libelleATC",
      "valueString" : "grippe, virus inactivé, fragmenté ou antigène de surface"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_62464573"
    }]
  },
  {
    "code" : "3400933652166",
    "display" : "INFLUVAC, suspension injectable en seringue préremplie, vaccin grippal inactivé à antigènes de surface - 1 seringue(s) préremplie(s) en verre de 0,5 ml avec aiguille(s)",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3365216"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400891734690"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9173469"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "INFLUVAC INJ SRG0,5ML"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "62027876"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "INFLUVAC, suspension injectable en seringue préremplie, vaccin grippal inactivé à antigènes de surface"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07BB02"
    },
    {
      "code" : "libelleATC",
      "valueString" : "grippe, virus inactivé, fragmenté ou antigène de surface"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_62027876"
    }]
  },
  {
    "code" : "3400936873742",
    "display" : "REPEVAX, suspension injectable en seringue préremplie. Vaccin diphtérique, tétanique, coquelucheux (acellulaire, multicomposé) et poliomyélitique (inactivé), (adsorbé, à teneur réduite en antigène(s)) - 1 seringue(s) préremplie(s) en verre de 0,5 ml munie d'un bouchon-piston chlorobutyle élastomère sans aiguille attachée avec un capuchon tip-cap avec une aiguille séparée",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3687374"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400890033244"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9003324"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "REPEVAX INJ SRG 1 S/A+"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "67619892"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "REPEVAX, suspension injectable en seringue préremplie. Vaccin diphtérique, tétanique, coquelucheux (acellulaire, multicomposé) et poliomyélitique (inactivé), (adsorbé, à teneur réduite en antigène(s))"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07CA02"
    },
    {
      "code" : "libelleATC",
      "valueString" : "diphtérie-coqueluche-poliomyélite-tétanos"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_67619892"
    }]
  },
  {
    "code" : "3400936873971",
    "display" : "REPEVAX, suspension injectable en seringue préremplie. Vaccin diphtérique, tétanique, coquelucheux (acellulaire, multicomposé) et poliomyélitique (inactivé), (adsorbé, à teneur réduite en antigène(s)) - 1 seringue(s) préremplie(s) en verre de 0,5 ml munie d'un bouchon-piston chlorobutyle élastomère sans aiguille attachée avec un capuchon tip-cap avec deux aiguilles séparées",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3687397"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400892911052"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9291105"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "REPEVAX INJ SRG S/A+2"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "67619892"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "REPEVAX, suspension injectable en seringue préremplie. Vaccin diphtérique, tétanique, coquelucheux (acellulaire, multicomposé) et poliomyélitique (inactivé), (adsorbé, à teneur réduite en antigène(s))"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07CA02"
    },
    {
      "code" : "libelleATC",
      "valueString" : "diphtérie-coqueluche-poliomyélite-tétanos"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_67619892"
    }]
  },
  {
    "code" : "3400934822353",
    "display" : "TETRAVAC-ACELLULAIRE, suspension injectable en seringue préremplie. Vaccin diphtérique, tétanique, coquelucheux acellulaire et poliomyélitique (inactivé), adsorbé - 1 seringue(s) préremplie(s) en verre de 0,5 ml",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3482235"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400892099026"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9209902"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "TETRAVAC-ACELLULAIRE SRG"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "66543281"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "TETRAVAC-ACELLULAIRE, suspension injectable en seringue préremplie. Vaccin diphtérique, tétanique, coquelucheux acellulaire et poliomyélitique (inactivé), adsorbé"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07CA02"
    },
    {
      "code" : "libelleATC",
      "valueString" : "diphtérie-coqueluche-poliomyélite-tétanos"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_66543281"
    }]
  },
  {
    "code" : "3400936874923",
    "display" : "TETRAVAC-ACELLULAIRE, suspension injectable en seringue préremplie. Vaccin diphtérique, tétanique, coquelucheux acellulaire et poliomyélitique (inactivé), adsorbé - 1 seringue(s) préremplie(s) en verre de 0,5 ml avec 2 aiguille(s) séparées, avec tip-cap",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3687492"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400892895680"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9289568"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "TETRAVAC-ACELLULAIRE SRG1 A/2A"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "66543281"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "TETRAVAC-ACELLULAIRE, suspension injectable en seringue préremplie. Vaccin diphtérique, tétanique, coquelucheux acellulaire et poliomyélitique (inactivé), adsorbé"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07CA02"
    },
    {
      "code" : "libelleATC",
      "valueString" : "diphtérie-coqueluche-poliomyélite-tétanos"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_66543281"
    }]
  },
  {
    "code" : "3400936874633",
    "display" : "TETRAVAC-ACELLULAIRE, suspension injectable en seringue préremplie. Vaccin diphtérique, tétanique, coquelucheux acellulaire et poliomyélitique (inactivé), adsorbé - 1 seringue(s) préremplie(s) en verre de 0,5 ml avec 1 aiguille séparée, avec tip-cap",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3687463"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400890033251"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9003325"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "TETRAVAC-ACELLULAIRE SRG A/1A"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "66543281"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "TETRAVAC-ACELLULAIRE, suspension injectable en seringue préremplie. Vaccin diphtérique, tétanique, coquelucheux acellulaire et poliomyélitique (inactivé), adsorbé"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07CA02"
    },
    {
      "code" : "libelleATC",
      "valueString" : "diphtérie-coqueluche-poliomyélite-tétanos"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_66543281"
    }]
  },
  {
    "code" : "3400936773875",
    "display" : "BOOSTRIXTETRA, suspension injectable en seringue préremplie. Vaccin diphtérique, tétanique, coquelucheux (acellulaire multicomposé) et poliomyélitique (inactivé), (adsorbé, à teneur réduite en antigènes) - 1 seringue(s) préremplie(s) en verre de 0,5 ml avec aiguille(s)",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3677387"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400892752532"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9275253"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "BOOSTRIXTETRA INJ SRG0,5ML+A"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "62404793"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "BOOSTRIXTETRA, suspension injectable en seringue préremplie. Vaccin diphtérique, tétanique, coquelucheux (acellulaire multicomposé) et poliomyélitique (inactivé), (adsorbé, à teneur réduite en antigènes)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07CA02"
    },
    {
      "code" : "libelleATC",
      "valueString" : "diphtérie-coqueluche-poliomyélite-tétanos"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_62404793"
    }]
  },
  {
    "code" : "3400935524676",
    "display" : "INFANRIXTETRA, suspension injectable en seringue préremplie. Vaccin diphtérique, tétanique, coquelucheux acellulaire, poliomyélitique inactivé, adsorbé - 1 seringue(s) préremplie(s) en verre de 0,5 ml",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3552467"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400892305691"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9230569"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "INFANRIXTETRA INJ SRG0,5ML"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "69777706"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "INFANRIXTETRA, suspension injectable en seringue préremplie. Vaccin diphtérique, tétanique, coquelucheux acellulaire, poliomyélitique inactivé, adsorbé"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07CA02"
    },
    {
      "code" : "libelleATC",
      "valueString" : "diphtérie-coqueluche-poliomyélite-tétanos"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_69777706"
    }]
  },
  {
    "code" : "3400936876064",
    "display" : "REVAXIS, suspension injectable en seringue préremplie. Vaccin diphtérique, tétanique et poliomyélitique (inactivé), adsorbé, à teneur réduite en antigènes - 1 seringue(s) préremplie(s) en verre de 0,5 ml avec aiguille(s) avec tip-cap",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3687606"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400890033268"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9003326"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "REVAXIS INJ SRG0,5ML A/1AIG"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "60917345"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "REVAXIS, suspension injectable en seringue préremplie. Vaccin diphtérique, tétanique et poliomyélitique (inactivé), adsorbé, à teneur réduite en antigènes"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07CA01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "diphtérie-poliomyélite-tétanos"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_60917345"
    }]
  },
  {
    "code" : "3400936876293",
    "display" : "REVAXIS, suspension injectable en seringue préremplie. Vaccin diphtérique, tétanique et poliomyélitique (inactivé), adsorbé, à teneur réduite en antigènes - 1 seringue(s) préremplie(s) en verre de 0,5 ml avec 2 aiguille(s) avec tip-cap",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3687629"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400892895451"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9289545"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "REVAXIS INJ SRG0,5ML A/2AIG"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "60917345"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "REVAXIS, suspension injectable en seringue préremplie. Vaccin diphtérique, tétanique et poliomyélitique (inactivé), adsorbé, à teneur réduite en antigènes"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07CA01"
    },
    {
      "code" : "libelleATC",
      "valueString" : "diphtérie-poliomyélite-tétanos"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_60917345"
    }]
  },
  {
    "code" : "3400927350078",
    "display" : "HEXYON, suspension injectable en seringue préremplie - 1 seringue(s) préremplie(s) en verre de 0,5 ml avec 1 aiguille(s)",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "2735007"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400890033237"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9003323"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "HEXYON INJ SRG0,5ML + 1AIG"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "60645557"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "HEXYON, suspension injectable en seringue préremplie"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07CA09"
    },
    {
      "code" : "libelleATC",
      "valueString" : "diphtérie-Haemophilus influenzae B-coqueluche-polio-tétanos-hépatite B"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_60645557"
    }]
  },
  {
    "code" : "3400927350368",
    "display" : "HEXYON, suspension injectable en seringue préremplie - 1 seringue(s) préremplie(s) en verre de 0,5 ml avec 2 aiguille(s)",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "2735036"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400894111184"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9411118"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "HEXYON INJ SRG0,5ML + 20AIG"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "60645557"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "HEXYON, suspension injectable en seringue préremplie"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07CA09"
    },
    {
      "code" : "libelleATC",
      "valueString" : "diphtérie-Haemophilus influenzae B-coqueluche-polio-tétanos-hépatite B"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_60645557"
    }]
  },
  {
    "code" : "3400935495839",
    "display" : "INFANRIX hexa, poudre et suspension pour suspension injectable en seringue préremplie. Vaccin diphtérique(D), tétanique(T), coquelucheux (acellulaire, multicomposé)(Ca), de l'hépatite B (ADNr)(HepB), poliomyélitique(inactivé)(P) et de l'Haemophilus influe - 1 flacon(s) en verre - 1 seringue(s) préremplie(s) en verre de 0,5 ml avec 2 aiguille(s)",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3549583"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400892370057"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9237005"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "INFANRIX HEXA INJ FL+SRG+AIG"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "62966063"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "INFANRIX hexa, poudre et suspension pour suspension injectable en seringue préremplie. Vaccin diphtérique(D), tétanique(T), coquelucheux (acellulaire, multicomposé)(Ca), de l'hépatite B (ADNr)(HepB), poliomyélitique(inactivé)(P) et de l'Haemophilus influe"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07CA09"
    },
    {
      "code" : "libelleATC",
      "valueString" : "diphtérie-Haemophilus influenzae B-coqueluche-polio-tétanos-hépatite B"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_62966063"
    }]
  },
  {
    "code" : "3400930079799",
    "display" : "VAXELIS, suspension injectable en seringue préremplie. Vaccin diphtérique, tétanique, coquelucheux (acellulaire, multicomposé), de l'hépatite B (ADNr), poliomyélitique (inactivé) et conjugué de l'Haemophilus de type b (adsorbé) - 1 seringue préremplie en verre  de 0,5 ml + 2 aiguilles",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400894259596"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9425959"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "VAXELIS INJ SRG0,5ML +2AIG"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "69688620"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "VAXELIS, suspension injectable en seringue préremplie. Vaccin diphtérique, tétanique, coquelucheux (acellulaire, multicomposé), de l'hépatite B (ADNr), poliomyélitique (inactivé) et conjugué de l'Haemophilus de type b (adsorbé)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07CA09"
    },
    {
      "code" : "libelleATC",
      "valueString" : "diphtérie-Haemophilus influenzae B-coqueluche-polio-tétanos-hépatite B"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_69688620"
    }]
  },
  {
    "code" : "3400930079782",
    "display" : "VAXELIS, suspension injectable en seringue préremplie. Vaccin diphtérique, tétanique, coquelucheux (acellulaire, multicomposé), de l'hépatite B (ADNr), poliomyélitique (inactivé) et conjugué de l'Haemophilus de type b (adsorbé) - 1 seringue préremplie en verre  de 0,5 ml + 1 aiguille",
    "property" : [{
      "code" : "ucdCode13",
      "valueCode" : "3400894259428"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9425942"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "VAXELIS INJ SRG0,5ML +1AIG"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "69688620"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "VAXELIS, suspension injectable en seringue préremplie. Vaccin diphtérique, tétanique, coquelucheux (acellulaire, multicomposé), de l'hépatite B (ADNr), poliomyélitique (inactivé) et conjugué de l'Haemophilus de type b (adsorbé)"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07CA09"
    },
    {
      "code" : "libelleATC",
      "valueString" : "diphtérie-Haemophilus influenzae B-coqueluche-polio-tétanos-hépatite B"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_69688620"
    }]
  },
  {
    "code" : "3400936077836",
    "display" : "TYAVAX, suspension et solution pour suspension injectable en seringue préremplie. Vaccin de l'hépatite A (inactivé, adsorbé) et typhoïdique polyosidique - 1 seringue(s) préremplie(s) bicompartimenté(e)(s)/à 2 compartiments en verre de 0,5 ml avec aiguille(s)",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3607783"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400892514598"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9251459"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "TYAVAX INJ SRG1ML A/AIG"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "69725264"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "TYAVAX, suspension et solution pour suspension injectable en seringue préremplie. Vaccin de l'hépatite A (inactivé, adsorbé) et typhoïdique polyosidique"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07CA10"
    },
    {
      "code" : "libelleATC",
      "valueString" : "typhoïde-hépatite A"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_69725264"
    }]
  },
  {
    "code" : "3400936874343",
    "display" : "PENTAVAC, poudre et suspension pour suspension injectable en seringue préremplie. Vaccin diphtérique, tétanique, coquelucheux (acellulaire, multicomposé), poliomyélitique (inactivé) et conjugué de l'haemophilus type b, adsorbé - 1 flacon(s) en verre - 1 seringue(s) préremplie(s) en verre de 0,5 ml muni d'un tip-cap avec 2 aiguille(s) séparées",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3687434"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400892862224"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9286222"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "PENTAVAC INJ FL+SRG A/2AIG"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "69811279"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "PENTAVAC, poudre et suspension pour suspension injectable en seringue préremplie. Vaccin diphtérique, tétanique, coquelucheux (acellulaire, multicomposé), poliomyélitique (inactivé) et conjugué de l'haemophilus type b, adsorbé"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07CA06"
    },
    {
      "code" : "libelleATC",
      "valueString" : "diphtérie-Haemophilus influenzae B-coqueluche-poliomyélite-tétanos"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_69811279"
    }]
  },
  {
    "code" : "3400935524737",
    "display" : "INFANRIXQUINTA, poudre et suspension pour suspension injectable. Vaccin diphtérique (D), tétanique (T), coquelucheux (acellulaire, multicomposé) (Ca), poliomyélitique (inactivé) (P) et conjugué de l’Haemophilus influenzae type b (Hib), adsorbé - 1 flacon(s) en verre - 1 seringue(s) préremplie(s) en verre de 0,5 ml avec aiguille(s) séparée(s)",
    "property" : [{
      "code" : "CIP7",
      "valueCode" : "3552473"
    },
    {
      "code" : "ucdCode13",
      "valueCode" : "3400892305523"
    },
    {
      "code" : "ucdCode7",
      "valueCode" : "9230552"
    },
    {
      "code" : "libelleUCD",
      "valueString" : "INFANRIXQUINTA INJ FL+SRG"
    },
    {
      "code" : "codeCIS",
      "valueCode" : "69543678"
    },
    {
      "code" : "libelleCIS",
      "valueString" : "INFANRIXQUINTA, poudre et suspension pour suspension injectable. Vaccin diphtérique (D), tétanique (T), coquelucheux (acellulaire, multicomposé) (Ca), poliomyélitique (inactivé) (P) et conjugué de l’Haemophilus influenzae type b (Hib), adsorbé"
    },
    {
      "code" : "codeATC",
      "valueCode" : "J07CA06"
    },
    {
      "code" : "libelleATC",
      "valueString" : "diphtérie-Haemophilus influenzae B-coqueluche-poliomyélite-tétanos"
    },
    {
      "code" : "classCIS",
      "valueString" : "http://data.esante.gouv.fr/ansm/medicament/SpecialitePharmaceutique_69543678"
    }]
  }]
}

```
